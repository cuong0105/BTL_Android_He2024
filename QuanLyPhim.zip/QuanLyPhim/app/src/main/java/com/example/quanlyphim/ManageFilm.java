package com.example.quanlyphim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlyphim.adapter.FilmRecycleViewAdapter;
import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Film;

import java.util.List;

public class ManageFilm extends AppCompatActivity {
    RecyclerView rcFilm;
    Button btnBack, btnAdd, topFilm;
    FilmRecycleViewAdapter adapter;
    SQLiteHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_film);
        initView();
        db=  new SQLiteHelper(this);
        List<Film> list = db.getAllFilm();
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        rcFilm.setLayoutManager(manager);
        rcFilm.setAdapter(adapter);
        adapter.setItemListener(new FilmRecycleViewAdapter.ItemListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(ManageFilm.this, UpdateDeleteFilm.class);
                Film f = adapter.getItem(position);
                intent.putExtra("film",f);
                startActivity(intent);
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManageFilm.this, AddFilm.class);
                startActivity(intent);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        topFilm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ManageFilm.this, TopFilm.class);
                startActivity(i);
            }
        });
    }

    public void initView(){
        rcFilm = findViewById(R.id.rc_film);
        btnAdd = findViewById(R.id.btn_add);
        btnBack = findViewById(R.id.btn_back);
        topFilm = findViewById(R.id.topfilm);
        adapter = new FilmRecycleViewAdapter(this);
    }

    @Override
    public void onResume(){
        super.onResume();
        List<Film> list = db.getAllFilm();
        adapter.setList(list);
    }
}