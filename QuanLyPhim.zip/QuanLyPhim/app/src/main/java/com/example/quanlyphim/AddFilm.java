package com.example.quanlyphim;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;

import java.util.ArrayList;
import java.util.List;

public class AddFilm extends AppCompatActivity {
    Button back,add;
    EditText name,link,des;
    Spinner spCate;
    RatingBar rate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_film);
        initView();
        SQLiteHelper db = new SQLiteHelper(this);
        List<Category> listCate = db.getAllCategory();
        List<String> listCateString = new ArrayList<>();
        for(Category i : listCate){
            listCateString.add(i.getName());
        }
        spCate.setAdapter(new ArrayAdapter<String>(AddFilm.this,R.layout.item_spinner,listCateString));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ten = name.getText().toString();
                String anh = link.getText().toString();
                String mota = des.getText().toString();
                int theloai = 0;
                for(Category c : listCate){
                    if (c.getName().equals(spCate.getSelectedItem().toString())){
                        theloai = c.getId();
                        break;
                    }
                }
                int vote = (int) rate.getRating();
                db.addFilm(new Film(ten,theloai,mota,anh,vote));
                finish();
            }
        });
    }

    public void initView(){
        back = findViewById(R.id.btn_back);
        add = findViewById(R.id.btn_add);
        name = findViewById(R.id.edNameFilm);
        link = findViewById(R.id.edLinkFilm);
        des = findViewById(R.id.edDesFilm);
        spCate = findViewById(R.id.spCate);
        rate = findViewById(R.id.rateFilm);
    }
}