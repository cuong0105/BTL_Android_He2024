package com.example.quanlyphim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;

public class UpdateCategory extends AppCompatActivity {
    EditText edName,edDes;
    Button btnBack,btnUpdate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_category);
        initView();
        Intent i = getIntent();
        Category c = (Category) i.getSerializableExtra("category", Category.class);
        edName.setText(c.getName());
        edDes.setText(c.getDes());
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edName.getText().toString();
                String des = edDes.getText().toString();
                SQLiteHelper db= new SQLiteHelper(UpdateCategory.this);
                db.updateCategory(new Category(c.getId(),name,des));
                Toast.makeText(UpdateCategory.this, "Update thanh cong", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    public void initView(){
        edName = findViewById(R.id.ed_name_category);
        edDes = findViewById(R.id.ed_des_category);
        btnBack = findViewById(R.id.btn_back);
        btnUpdate = findViewById(R.id.btn_update);
    }
}