package com.example.quanlyphim.model;

import java.io.Serializable;

public class Category implements Serializable {
    int id;
    String name,des;

    public Category() {
    }

    public Category(int id, String name, String des) {
        this.id = id;
        this.name = name;
        this.des = des;
    }

    public Category(String name,String des){
        this.name = name;
        this.des = des;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
