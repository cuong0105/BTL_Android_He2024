package com.example.quanlyphim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlyphim.adapter.CategoryRecycleViewAdapter;
import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;

import java.util.List;

public class ManageCategory extends AppCompatActivity {
    RecyclerView rcCategory;
    Button btnBack, btnAdd;

    CategoryRecycleViewAdapter adapter;
    SQLiteHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_category);
        initView();
        db=  new SQLiteHelper(this);
        List<Category> list = db.getAllCategory();
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        rcCategory.setLayoutManager(manager);
        rcCategory.setAdapter(adapter);
        adapter.setItemListener(new CategoryRecycleViewAdapter.ItemListener() {
            @Override
            public void onItemClick(View view, int position) {
                Category item = adapter.getItem(position);
                Intent intent = new Intent(ManageCategory.this, CategoryFeature.class);
                intent.putExtra("category",item);
                startActivity(intent);
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManageCategory.this,AddCategory.class);
                startActivity(intent);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void initView(){
        rcCategory = findViewById(R.id.rc_category);
        btnAdd = findViewById(R.id.btn_add);
        btnBack = findViewById(R.id.btn_back);
        adapter = new CategoryRecycleViewAdapter();
    }

    @Override
    public void onResume(){
        super.onResume();
        List<Category> list = db.getAllCategory();
        adapter.setList(list);
    }
}