package com.example.quanlyphim;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;

import java.util.List;

public class CategoryFeature extends AppCompatActivity {
    Button view,update,delete,back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_feature);
        initView();
        Intent i = getIntent();
        Category category = (Category) i.getSerializableExtra("category", Category.class);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoryFeature.this, UpdateCategory.class);
                intent.putExtra("category",category);
                startActivity(intent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Thong bao xoa!");
                builder.setMessage("Ban co chac muon xoa "+category.getName()+" khong?");
                builder.setPositiveButton("Co", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SQLiteHelper db = new SQLiteHelper(getApplicationContext());
                        db.deleteCategory(category.getId());
                        List<Film> listFilm = db.getAllFilm();
                        for(Film f : listFilm){
                            if(f.getCategory() == category.getId()){
                                db.deleteFilm(f.getId());
                            }
                        }
                        Toast.makeText(CategoryFeature.this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.setNegativeButton("Khong", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(CategoryFeature.this,FilmByCategory.class);
                i2.putExtra("category",category);
                startActivity(i2);
            }
        });
    }

    public void initView(){
        view = findViewById(R.id.btn_view_list_film);
        update = findViewById(R.id.btn_update_category);
        delete = findViewById(R.id.btn_delete_category);
        back = findViewById(R.id.btn_back);
    }
}