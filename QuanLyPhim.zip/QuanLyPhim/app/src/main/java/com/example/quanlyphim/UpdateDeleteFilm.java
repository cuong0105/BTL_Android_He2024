package com.example.quanlyphim;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;

import java.util.ArrayList;
import java.util.List;

public class UpdateDeleteFilm extends AppCompatActivity {
    Button back,update,delete;
    EditText name,link,des;
    Spinner spCate;
    RatingBar rate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete_film);
        initView();
        SQLiteHelper db = new SQLiteHelper(this);
        List<Category> listCate = db.getAllCategory();
        List<String> listCateString = new ArrayList<>();
        for(Category i : listCate){
            listCateString.add(i.getName());
        }
        spCate.setAdapter(new ArrayAdapter<String>(UpdateDeleteFilm.this,R.layout.item_spinner,listCateString));
        Intent i = getIntent();
        Film f = (Film)i.getSerializableExtra("film", Film.class);
        int p = 0;
        for(int k = 0 ; k < listCate.size(); k++){
            if(listCate.get(k).getId()==(f.getCategory())){
                p = k;
                break;
            }
        }
        spCate.setSelection(p);
        rate.setRating(f.getVote());
        name.setText(f.getName());
        des.setText(f.getDes());
        link.setText(f.getLink());

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Thong bao xoa!");
                builder.setMessage("Ban co chac muon xoa "+f.getName()+" khong?");
                builder.setPositiveButton("Co", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SQLiteHelper db = new SQLiteHelper(getApplicationContext());
                        db.deleteFilm(f.getId());
                        Toast.makeText(UpdateDeleteFilm.this,"Xoa thanh cong", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.setNegativeButton("Khong", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ten = name.getText().toString();
                String anh = link.getText().toString();
                String mota = des.getText().toString();
                int theloai = 0;
                for(Category c : listCate){
                    if (c.getName().equals(spCate.getSelectedItem().toString())){
                        theloai = c.getId();
                        break;
                    }
                }
                int vote = (int) rate.getRating();
                db.updateFilm(new Film(f.getId(),ten,theloai,mota,anh,vote));
                Toast.makeText(UpdateDeleteFilm.this, "Update sach thanh cong", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    public void initView(){
        back = findViewById(R.id.btn_back);
        update = findViewById(R.id.btn_update);
        delete = findViewById(R.id.btn_delete);
        name = findViewById(R.id.edNameFilm);
        link = findViewById(R.id.edLinkFilm);
        des = findViewById(R.id.edDesFilm);
        spCate = findViewById(R.id.spCate);
        rate = findViewById(R.id.rateFilm);
    }
}