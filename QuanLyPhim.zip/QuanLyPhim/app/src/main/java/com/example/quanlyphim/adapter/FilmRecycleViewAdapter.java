package com.example.quanlyphim.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlyphim.R;
import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class FilmRecycleViewAdapter extends RecyclerView.Adapter<FilmRecycleViewAdapter.FilmViewHolder>{

    private List<Film> list;
    private ItemListener itemListener;

    Context context;
    public FilmRecycleViewAdapter(Context context){
        this.context = context;
        list = new ArrayList<>();
    }
    public  void  setList(List<Film> list){
        this.list = list;
        notifyDataSetChanged();
    }

    public void setItemListener(ItemListener itemListener) {
        this.itemListener = itemListener;
    }

    public Film getItem(int position){
        return list.get(position);
    }
    @NonNull
    @Override
    public FilmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_film,parent,false);
        return new FilmViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FilmViewHolder holder, int position) {
        Film item = list.get(position);
        holder.name.setText(item.getName());
        holder.des.setText(item.getDes());
        holder.vote.setRating(item.getVote());
        SQLiteHelper db = new SQLiteHelper(context);
        List<Category> listCate = db.getAllCategory();
        for(Category c : listCate){
            if(c.getId() == item.getCategory()){
                holder.cate.setText(c.getName());
                break;
            }
        }
        Picasso.get().load(item.getLink()).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public class FilmViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView img;
        TextView name,cate,des;
        RatingBar vote;
        public FilmViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.nameFilm);
            cate = itemView.findViewById(R.id.categoryFilm);
            img = itemView.findViewById(R.id.imgFilm);
            vote = itemView.findViewById(R.id.voteFilm);
            des = itemView.findViewById(R.id.desFilm);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if(itemListener!=null){
                itemListener.onItemClick(v,getAdapterPosition());
            }
        }
    }

    public interface ItemListener{
        void onItemClick(View view,int position);
    }
}
