package com.example.quanlyphim;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;

public class AddCategory extends AppCompatActivity {
    EditText edName,edDes;
    Button btnBack,btnAdd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);
        initView();
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edName.getText().toString().trim();
                String des = edDes.getText().toString().trim();
                if(name.isEmpty()){
                    Toast.makeText(AddCategory.this, "Vui long dien thong tin", Toast.LENGTH_SHORT).show();
                }
                else{
                    SQLiteHelper db = new SQLiteHelper(AddCategory.this);
                    db.addCategory(new Category(name,des));
                    Toast.makeText(AddCategory.this, "Them the loai thanh cong", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    public void initView(){
        edName = findViewById(R.id.ed_name_category);
        edDes = findViewById(R.id.ed_des_category);
        btnBack = findViewById(R.id.btn_back);
        btnAdd = findViewById(R.id.btn_add);
    }
}