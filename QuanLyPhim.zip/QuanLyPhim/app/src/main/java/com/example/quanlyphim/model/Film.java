package com.example.quanlyphim.model;

import java.io.Serializable;

public class Film implements Serializable {
    int id;
    String name;
    int category;
    String des,link;
    int vote;

    public Film() {
    }

    public Film(int id, String name, int category, String des, String link, int vote) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.des = des;
        this.link = link;
        this.vote = vote;
    }

    public Film(String name, int category, String des, String link, int vote) {
        this.name = name;
        this.category = category;
        this.des = des;
        this.link = link;
        this.vote = vote;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getVote() {
        return vote;
    }

    public void setVote(int vote) {
        this.vote = vote;
    }
}
