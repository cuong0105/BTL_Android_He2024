package com.example.quanlyphim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlyphim.adapter.FilmRecycleViewAdapter;
import com.example.quanlyphim.data.SQLiteHelper;
import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;

import java.util.ArrayList;
import java.util.List;

public class FilmByCategory extends AppCompatActivity {
    RecyclerView rcFilm;
    Button btnBack;
    FilmRecycleViewAdapter adapter;
    SQLiteHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_by_category);
        initView();
        db=  new SQLiteHelper(this);
        List<Film> list = db.getAllFilm();
        Intent i1 = getIntent();
        Category c = (Category)i1.getSerializableExtra("category");
        List<Film> list1= new ArrayList<>();
        for(Film f  : list){
            if(f.getCategory() == c.getId()){
                list1.add(f);
            }
        }
        adapter.setList(list1);
        LinearLayoutManager manager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        rcFilm.setLayoutManager(manager);
        rcFilm.setAdapter(adapter);
        adapter.setItemListener(new FilmRecycleViewAdapter.ItemListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(FilmByCategory.this, UpdateDeleteFilm.class);
                Film f = adapter.getItem(position);
                intent.putExtra("film",f);
                startActivity(intent);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void initView(){
        rcFilm = findViewById(R.id.rc_film);
        btnBack = findViewById(R.id.btn_back);
        adapter = new FilmRecycleViewAdapter(this);
    }

    @Override
    public void onResume(){
        super.onResume();
        List<Film> list = db.getAllFilm();
        Intent i1 = getIntent();
        Category c = (Category)i1.getSerializableExtra("category", Category.class);
        List<Film> list1= new ArrayList<>();
        for(Film f  : list){
            if(f.getCategory() == c.getId()){
                list1.add(f);
            }
        }
        adapter.setList(list1);
    }
}