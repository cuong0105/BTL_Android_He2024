package com.example.quanlyphim.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.quanlyphim.model.Category;
import com.example.quanlyphim.model.Film;

import java.util.ArrayList;
import java.util.List;

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "QuanLyPhim.db";
    private static int DATABASE_VERSION = 1;
    public SQLiteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE theloai("+"id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "ten TEXT,mota TEXT)";
        db.execSQL(sql);

        String sql1 = "CREATE TABLE phim("+"id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "ten TEXT,idtheloai INTEGER,mota TEXT,link TEXT,vote INTEGER)";
        db.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    //get all category
    public List<Category> getAllCategory(){
        List<Category> res = new ArrayList<>();
        SQLiteDatabase st = getReadableDatabase();
        String order = "ten DESC";
        Cursor rs = st.query("theloai",null,null,null,null,null,order);
        while (rs!=null && rs.moveToNext()){
            int id = rs.getInt(0);
            String name = rs.getString(1);
            String des = rs.getString(2);
            res.add(new Category(id,name,des));
        }
        return res;
    }

    // add category
    public long addCategory(Category i){
        ContentValues values = new ContentValues();
        values.put("ten",i.getName());
        values.put("mota",i.getDes());
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.insert("theloai",null,values);
    }

    //delete category
    public int deleteCategory(int id){
        String whereClase = "id= ?";
        String[] whereArgs = {Integer.toString(id)};
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.delete("theloai",whereClase,whereArgs);
    }
    //update category
    public int updateCategory(Category i){
        ContentValues values = new ContentValues();
        values.put("ten",i.getName());
        values.put("mota",i.getDes());
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        String whereClase = "id= ?";
        String[] whereArgs = {Integer.toString(i.getId())};
        return sqLiteDatabase.update("theloai",values,whereClase,whereArgs);
    }
    //get all film
    public List<Film> getAllFilm(){
        List<Film> res = new ArrayList<>();
        SQLiteDatabase st = getReadableDatabase();
        String order = "ten DESC";
        Cursor rs = st.query("phim",null,null,null,null,null,order);
        while (rs!=null && rs.moveToNext()){
            int id = rs.getInt(0);
            String name = rs.getString(1);
            int cate = rs.getInt(2);
            String des = rs.getString(3);
            String link = rs.getString(4);
            int vote = rs.getInt(5);
            res.add(new Film(id,name,cate,des,link,vote));
        }
        return res;
    }

    //add film
    public long addFilm(Film i){
        ContentValues values = new ContentValues();
        values.put("ten",i.getName());
        values.put("mota",i.getDes());
        values.put("idtheloai",i.getCategory());
        values.put("link",i.getLink());
        values.put("vote",i.getVote());
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.insert("phim",null,values);
    }

    //delete film
    public int deleteFilm(int id){
        String whereClase = "id= ?";
        String[] whereArgs = {Integer.toString(id)};
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.delete("phim",whereClase,whereArgs);
    }
    //update film
    public int updateFilm(Film i){
        ContentValues values = new ContentValues();
        values.put("ten",i.getName());
        values.put("mota",i.getDes());
        values.put("idtheloai",i.getCategory());
        values.put("link",i.getLink());
        values.put("vote",i.getVote());
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        String whereClase = "id= ?";
        String[] whereArgs = {Integer.toString(i.getId())};
        return sqLiteDatabase.update("phim",values,whereClase,whereArgs);
    }
}
